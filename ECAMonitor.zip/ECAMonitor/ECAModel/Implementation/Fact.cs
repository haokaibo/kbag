﻿using System;

namespace ECAModel
{
    public class Fact : IFact
    {
        #region IFact Members

        public string USN { get; set; }

        public string Type { get; set; }
        public string Detail { get; set; }

        public DateTime Sent { get; set; }

        public string RICs { get; set; }

        public string Alert { get; set; }

        public string Product { get; set; }
        public string Topic { get; set; }
        public string Language { get; set; }
        #endregion
    }
}
