﻿
using System;
namespace ECAModel
{
    [Serializable]
    public class StorySummary : IStorySummary
    {
        #region IStorySummary Members

        public string StoryID
        { get; set; }

        public string Wire
        { get; set; }

        public DateTime AddedTime
        { get; set; }

        public string Headline
        { get; set; }

        public int Size
        { get; set; }

        public string Subject
        { get; set; }

        public string RIC
        { get; set; }

        public int SC
        { get; set; }

        public int CF
        { get; set; }

        public int WEFF
        { get; set; }

        public int SFF
        { get; set; }

        public int CFFacts
        { get; set; }

        public int WEFFFacts { get; set; }

        public int SFFFacts { get; set; }

        public int AggFacts { get; set; }

        public int TextFacts { get; set; }

        public int NSDFacts { get; set; }

        public int Alerts { get; set; }

        public string USN { get; set; }

        public string Product { get; set; }

        public string Topic { get; set; }

        public string Language { get; set; }

        #endregion
    }
}
