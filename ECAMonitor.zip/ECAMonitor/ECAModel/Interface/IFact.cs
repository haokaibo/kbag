﻿using System;

namespace ECAModel
{
    public interface IFact
    {
        string USN { get; set; }
        string Type { get; set; }
        string Detail { get; set; }
        DateTime Sent { get; set; }
        string RICs { get; set; }
        string Alert { get; set; }
        string Product { get; set; }
        string Topic { get; set; }
        string Language { get; set; }
    }
}
