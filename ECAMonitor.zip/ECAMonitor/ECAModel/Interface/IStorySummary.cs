﻿
using System;
namespace ECAModel
{
    public interface IStorySummary
    {
        string StoryID { get; set; }
        string Wire { get; set; }
        DateTime AddedTime { get; set; }
        string Headline { get; set; }
        int Size { get; set; }
        string Subject { get; set; }
        string RIC { get; set; }
        int SC { get; set; }
        int CF { get; set; }
        int WEFF { get; set; }
        int SFF { get; set; }
        int CFFacts { get; set; }
        int WEFFFacts { get; set; }
        int SFFFacts { get; set; }
        int AggFacts { get; set; }
        int TextFacts { get; set; }
        int NSDFacts { get; set; }
        int Alerts { get; set; }
        string USN { get; set; }
        string Product { get; set; }
        string Topic { get; set; }
        string Language { get; set; }
    }
}
