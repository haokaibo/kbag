﻿using System.Web.Mvc;

namespace ECAMonitor.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            ViewBag.Message = "Please select functions:";

            return View();
        }

        public ActionResult About()
        {
            return View();
        }
    }
}
