﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using ECAModel;
using Util;

namespace ECAMonitor.Controllers
{
    public class StoryStatisticController : Controller
    {
        private string[] RICs = new string[] { 
                "ENZ.N",
                "E2V.L",
                "MG.TO",
                "CAT.N",
                "CSH.N",
                "BRCM.O",
                "BTH.N",
                "BCE.TO",
                "AMP.N",
                "PHTM.L",
            };
        private string[] alerts = new string[] {
            "MAGNA INTERNATIONAL INC <MGA.TO> ANNOUNCES PUBLIC OFFERING OF COMMON STOCK TEST IGNORE RASHMI",
            "AUTO ALERT - CATERPILLAR INC <CAT.N> Q1 EPS ROSE 18 PCT TO 1.45 USD",
            "AUTO ALERT - CATERPILLAR INC <CAT.N> Q1 PROFIT ROSE 13 PCT TO 922 MLN USD",
            "CATERPILLAR REPORTS RECORD FIRST-QUARTER SALES AND PROFIT LED BY STRONG DEMAND",
            "AUTO ALERT - CASH AMERICA INTERNATIONAL INC <CSH.N> Q4 EPS 0.88 USD",
            "CASH AMERICA ANNOUNCES FOURTH QUARTER EARNINGS PER SHARE",
            "BROADCOM REPORTS FOURTH QUARTER AND YEAR 2007 RESULTS",
            "AUTO ALERT - BLYTH INC <BTH.N> Q4 OPER LOSS 3.9 MLN USD VS 24.6 MLN USD PROFIT YR AGO",
            "AUTO ALERT - BLYTH INC <BTH.N> Q4 SALES FELL 2 PCT TO 373.8 MLN USD",
            "BLYTH, INC. REPORTS 4TH QUARTER AND FULL YEAR SALES AND EARNINGS",
            "BCE REPORTS FOURTH QUARTER AND FULL YEAR 2007 RESULTS",
            "AUTO ALERT - AMERIPRISE FINANCIAL INC <AMP.N> Q4 ADJ EPS 0.05 USD",
            "AUTO ALERT - AMERIPRISE FINANCIAL INC <AMP.N> Q4 EPS 0.13 USD",
            "AUTO ALERT - AMERIPRISE FINANCIAL INC <AMP.N> Q4 DILUTED EPS ROSE 57 PCT TO 1.08 USD",
            "AUTO ALERT - AMERIPRISE FINANCIAL INC <AMP.N> Q4 ADJ DILUTED EPS ROSE 14 PCT TO 1.16 USD",
            "AUTO ALERT - AMERIPRISE FINANCIAL INC <AMP.N> Q4 REVENUE ROSE 8 PCT TO 2.3 BLN USD",
            "AUTO ALERT - AMERIPRISE FINANCIAL INC <AMP.N> Q4 NET PROFIT ROSE 49 PCT TO 255 MLN USD",
            "AMERIPRISE FINANCIAL REPORTS FOURTH QUARTER AND FULL YEAR 2007 RESULTS",
            "AUTO ALERT - PHOTO-ME INTERNATIONAL PLC <PHTM.L> INTERIM DIV 1 PENCE/SHR",
            "AUTO ALERT - PHOTO-ME INTERNATIONAL PLC <PHTM.L> H1 REVENUE ROSE 0.6 PCT TO 118.4 MLN STG",
        };

        private string[] details = new string[] {
            "STOCK_OFFERING",
            "EPS",
            "PRF",
            "RESULTS ",
            "REV",
        };

        private string[] types = new string[] { 
            "Headline",
            "Fact",
        };

        private string[] products = new string[] { 
            "IBM",
            "MSFT"
        };

        private string[] topics = new string[] {
            "Topic1",
            "Topic2"
        };
        private string[] languages = new string[] { 
            "en",
            "de"
        };
        //
        // GET: /StoryStatistic/

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult GetRecentStories(string sidx, string sord, int page, int rows)
        {
            bool bSearchOn = false;
            var searchOn = Request.Params["_search"];
            if (!string.IsNullOrEmpty(searchOn))
            {
                bSearchOn = bool.TryParse(searchOn.Trim(), out bSearchOn);
            }

            var filters = Request.Params["filters"];
            if (bSearchOn && !string.IsNullOrEmpty(filters))
            {
                //MvcApplication.JSSerializer.Deserialize<JqGridSearchFilter>(filters.Trim());
            }
            int pageIndex = Convert.ToInt32(page) - 1;
            int pageSize = rows;
            DateTime beginTime = DateTime.UtcNow.AddDays(-5);
            DateTime endTime = DateTime.UtcNow;

            int totalRecords = 100;
            int totalPages = (int)Math.Ceiling((float)totalRecords / (float)pageSize);
            //var trans = MvcApplication.FastWireDataProvider.GetPublications(filters, pageIndex + 1, pageSize, sidx + " " + sord);
            IList<IStorySummary> storySummaries = new List<IStorySummary>();//MvcApplication.FastWireDataProvider.GetPublicationsByTime(beginTime, endTime, pageIndex, pageSize, sidx, sord == "desc");
            string[] wires = new string[] { "PRN", "PZO", "BW", "RNZ", "CNW", "MW" };
            string[] headlines = new string[] { "Caterpillar Reports Record First-Quarter Sales and Profit Led by Strong Demand",
            "Cash America Announces Fourth Quarter Earnings Per Share",
            "Broadcom Reports Fourth Quarter and Year 2007 Results",
            "Blyth, Inc. Reports 4th Quarter and Full Year Sales and Earnings",
            "BCE Reports Fourth Quarter and Full Year 2007 Results",
            "Ameriprise Financial Reports Fourth Quarter and Full Year 2007 Results",
            "Photo-Me Intnl. - INTERIM RESULTS ANNOUNCEMENT",
            "Big Yellow Group PLC - Half Yearly Report",
            "RM PLC - Preliminary Results",
            "Persimmon Plc - Half Yearly Report"};

            string[] subjects = new string[] {
                "RESULTS",
                "STOCK_OFFERING",
                "ACQSTN",
            };
            for (int i = 0; i < 20; i++)
            {
                storySummaries.Add(new StorySummary()
                {
                    AddedTime = DateTime.Now,
                    AggFacts = i,
                    Alerts = i,
                    CF = i,
                    CFFacts = i,
                    Headline = headlines[i % headlines.Length],
                    NSDFacts = i,
                    RIC = RICs[i % RICs.Length],
                    SC = i,
                    SFF = i,
                    SFFFacts = i,
                    Size = i,
                    StoryID = string.Format("NTM-{0}-VQW-{1}", wires[i % wires.Length], 10000 + i),
                    Subject = subjects[i % subjects.Length],
                    TextFacts = i,
                    USN = string.Format("ECA00{0}HT", i),
                    WEFF = i,
                    WEFFFacts = i,
                    Wire = wires[i % wires.Length],
                    Language = languages[i % languages.Length],
                    Product = products[i % products.Length],
                    Topic = topics[i % products.Length]
                });
            }

            var jsonData = new
            {
                total = totalPages,
                page = page,
                records = totalRecords,
                rows = (
                          from storySummary in storySummaries
                          select new
                          {
                              id = storySummary.StoryID,
                              cell = new string[] {   
                                    storySummary.StoryID,
                                    storySummary.Wire,
                                    storySummary.Headline,
                                    storySummary.AddedTime.ToString(StringFormatter.PreciseTime),
                                    storySummary.Size.ToString(),

                                    storySummary.Subject, 
                                    storySummary.RIC,
                                    storySummary.Product,
                                    storySummary.Topic,
                                    storySummary.Language,
                                    storySummary.SC.ToString(),
                                    storySummary.CF.ToString(), 
                                    storySummary.WEFF.ToString(),

                                    storySummary.SFF.ToString(),
                                    storySummary.CFFacts.ToString(),
                                    storySummary.WEFFFacts.ToString(),
                                    storySummary.SFFFacts.ToString(),
                                    storySummary.AggFacts.ToString(),

                                    storySummary.TextFacts.ToString(),
                                    storySummary.NSDFacts.ToString(),
                                    storySummary.Alerts.ToString(),
                                    storySummary.USN,
                            }
                          }).ToArray()
            };
            return Json(jsonData, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetFactsByStoryId(string storyId)
        {

            IList<IFact> facts = new List<IFact>();
            for (int i = 0; i < 5; i++)
            {
                facts.Add(new Fact()
                {
                    USN = string.Format("ECA00{0}IE", i),
                    Alert = alerts[i % alerts.Length],
                    Detail = details[i % this.details.Length],
                    RICs = this.RICs[i % this.RICs.Length],
                    Sent = DateTime.Now,
                    Type = types[i % types.Length],
                    Language = languages[i % languages.Length],
                    Product = products[i % products.Length],
                    Topic = topics[i % products.Length]
                });
            }

            var jsonData = new
            {
                //total = totalPages, // we'll implement later 
                //page = page,
                //records = totalRecords, // implement later 
                rows = (
                          from fact in facts
                          select new
                          {
                              id = fact.USN,
                              cell = new string[] {
                               fact.USN,
                               fact.Type,
                               fact.Detail,
                               fact.Sent.ToString(StringFormatter.PreciseTime),
                               fact.RICs,
                               fact.Alert,
                               fact.Product,
                               fact.Topic,
                               fact.Language
                            }
                          }).ToArray()
            };
            return Json(jsonData, JsonRequestBehavior.AllowGet);
        }
    }
}
