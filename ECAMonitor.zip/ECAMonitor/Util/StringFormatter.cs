﻿
namespace Util
{
    public static class StringFormatter
    {
        public const string PreciseTime = "yyyy-MM-dd HH:mm:ss.fff";
    }
}
